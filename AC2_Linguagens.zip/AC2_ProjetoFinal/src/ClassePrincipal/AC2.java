package ClassePrincipal;

import View.SplashScreen;

public class AC2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*Grupo:
        Alexandre Rodrigues Sampaio 223957
        Jean Israel da Silva 223803
        Murilo Henrique Gonçalves bezerra 223896
        Rene Sanchez Battaglia 224032
        Vitor Hugo Guimarães da Silva 224029*/
    }

}
